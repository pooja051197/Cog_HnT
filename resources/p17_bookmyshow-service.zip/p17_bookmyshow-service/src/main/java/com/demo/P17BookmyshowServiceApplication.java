package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P17BookmyshowServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(P17BookmyshowServiceApplication.class, args);
	}

}
